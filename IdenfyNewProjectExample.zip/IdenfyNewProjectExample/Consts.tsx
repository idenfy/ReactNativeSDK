export const BASE_URL = 'https://ivs.idenfy.com/';
export const clientId = 'idenfySampleClientID';
export const scanRef = 'PUT_YOUR_SCAN_REF';
export const apiKey = 'PUT_YOUR_IDENFY_API_KEY_HERE';
export const apiSecret = 'PUT_YOUR_IDENFY_API_SECRET_HERE';
